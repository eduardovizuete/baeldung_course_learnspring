package com.baeldung.taskmanagementapplesson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagementAppLessonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagementAppLessonApplication.class, args);
	}

}
